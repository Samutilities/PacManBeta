package com.pacmanrevolution.game;

abstract class Menu implements Main {
	protected String namePlayer = " ";

	public Menu() {
		
	}

	public boolean beginMap () {
		
	}

	public void showResult (Result result) {
		
	}

	public String registerPlayer () {
		
	}

}
