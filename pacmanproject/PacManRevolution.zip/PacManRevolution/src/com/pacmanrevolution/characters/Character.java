package com.pacmanrevolution.characters;

abstract class Character extends Elements {
	private int characterSpeed = 100;
	private int characterX = 0;
	private int characterY = 0;

	public Character() {
		
	}

	public X,Y move (Button button) {
		
	}

	public boolean meetWall () {
		
	}

}
