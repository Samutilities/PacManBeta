package com.pacmanrevolution.characters;

class PacMan extends Character{
	protected int playerLife = 3;
	public  Sound soundEffects[];

	public PacMan() {
		
	}

	public boolean haveWin () {
		
	}

	public boolean swallowPacFreeze (PacMan.characterX , Pacman.caracterY , PacFreeze.quelquechose) {
		
	}

	public boolean swallowSuperPacGum () {
		
	}

	public boolean swallowFruit () {
		
	}

	public boolean swallowPacGum () {
		
	}

	public boolean swallowPacPrika () {
		
	}

	public boolean meetGhost () {
		
	}

	public boolean loseLife () {
		
	}

}
