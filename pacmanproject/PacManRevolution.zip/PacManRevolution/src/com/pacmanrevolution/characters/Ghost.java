package com.pacmanrevolution.characters;

abstract class Ghost  extends Character  {
	protected ScriptIa typeIa = null;
	protected boolean isFrozen = false;
	protected boolean isEaten = false;
	protected Sound soundEffectGhost = null;

	public Ghost (){
		
	}

	public boolean meetPlayer (){
		
	}

	public boolean focusPlayer (){
		
	}

}