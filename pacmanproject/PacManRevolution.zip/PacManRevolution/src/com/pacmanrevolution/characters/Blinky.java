package com.pacmanrevolution.characters;

class Blinky extends Ghost {

	public Blinky() {
		
	}

}
