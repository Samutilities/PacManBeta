package com.pacmanrevolution.objets;


class SuperPacGum extends Items {

	public SuperPacGum() {
		
	}

}