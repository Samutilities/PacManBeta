package com.pacmanrevolution.objets;

class PacPrika extends Items{

	public PacPrika() {

	}
}
