package com.pacmanrevolution.objets;

class PacFreeze extends Items {

	public PacFreeze() {
		
	}

}